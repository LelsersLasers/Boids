# Boids

2D customizable boids simulation in JavaScript.
Running live at: https://lelserslasers.itch.io/boids

![Cover](./Showcase/Cover.PNG)