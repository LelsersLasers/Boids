# Boids

2D customizable boids simulation in JavaScript

![Cover](./Showcase/Cover.PNG)

## TODO

- Itch.io page
  - SHOWCASE IMAGES + GIFS